import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface AuthPasswordStepProps {
  email: string;
  onBack: () => void;
}

export function AuthPasswordStep({ email, onBack }: AuthPasswordStepProps) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { signIn } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (password.length < 6) {
      toast({ variant: 'destructive', title: 'Erro', description: 'Senha deve ter pelo menos 6 caracteres' });
      return;
    }
    setLoading(true);
    
    try {
      const { error } = await signIn(email, password);
      
      if (error) {
        toast({
          variant: 'destructive',
          title: 'Erro ao entrar',
          description: error.message === 'Invalid login credentials' ? 'Senha incorreta' : error.message,
        });
      } else {
        // Redireciona imediatamente após login bem-sucedido
        // O Location.tsx verificará a permissão de GPS e presença
        navigate('/location', { replace: true });
      }
    } catch (err) {
      toast({
        variant: 'destructive',
        title: 'Erro inesperado',
        description: 'Tente novamente mais tarde',
      });
    } finally {
      setLoading(false);
    }
  };

const handleForgotPassword = async () => {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: 'https://app.katuu.com.br/reset-password',
    });
    
    if (error) {
      toast({ 
        variant: 'destructive', 
        title: 'Erro ao enviar email', 
        description: 'Não foi possível enviar o email de recuperação. Tente novamente.' 
      });
    } else {
      toast({ 
        title: 'Email enviado!', 
        description: 'Verifique sua caixa de entrada para redefinir sua senha.' 
      });
    }
  } catch {
    toast({ 
      variant: 'destructive', 
      title: 'Erro de conexão', 
      description: 'Verifique sua internet e tente novamente.' 
    });
  }
};

  return (
    <div className="w-full max-w-sm flex flex-col items-center">
      <h2 className="text-2xl font-bold text-white mb-1">Sua senha</h2>
      <p className="text-white/70 text-sm mb-6">{email}</p>

      <div className="w-full relative mb-2">
        <input
          type={showPassword ? 'text' : 'password'}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          className="w-full rounded-full py-3 px-6 pr-12 bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-white/40"
          autoFocus
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-4 top-1/2 -translate-y-1/2 text-white/50 hover:text-white transition-colors"
        >
          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
        </button>
      </div>

      <button
        onClick={handleLogin}
        disabled={loading}
        className="w-full bg-white text-gray-800 font-medium rounded-full py-3 px-6 shadow-md hover:shadow-lg transition-shadow mt-2 disabled:opacity-50"
      >
        {loading ? 'Entrando...' : 'Entrar'}
      </button>

      <button onClick={handleForgotPassword} className="mt-3 text-white/60 text-xs hover:text-white transition-colors">
        Esqueci minha senha
      </button>

      <button onClick={onBack} className="mt-3 flex items-center gap-1 text-white/70 text-sm hover:text-white transition-colors">
        <ArrowLeft className="w-4 h-4" /> Voltar
      </button>
    </div>
  );
}