import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/hooks/useProfile';
import { usePendingAction } from '@/hooks/usePendingAction';
import type { Gender } from '@/types/gender';
import { GENDER_OPTIONS } from '@/types/gender';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { DateOfBirthPicker } from '@/components/profile/DateOfBirthPicker';
import { InterestsStep } from '@/components/onboarding/InterestsStep';
import logoKatu from '@/assets/logo-katuu-oficial.png';

export default function Onboarding() {
  const { user } = useAuth();
  const { profile, updateProfile, updateInterests, isProfileComplete, loading } = useProfile();
  const { executePendingOrNavigate } = usePendingAction();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [step, setStep] = useState(1);
  const [nome, setNome] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [bio, setBio] = useState('');
  const [gender, setGender] = useState<Gender | ''>('');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [ageError, setAgeError] = useState('');
  const [categoryIndex, setCategoryIndex] = useState(0);

  useEffect(() => {
    if (!user) {
      navigate('/auth', { replace: true });
    } else if (!loading && isProfileComplete()) {
      navigate('/location', { replace: true });
    }
  }, [user, loading, isProfileComplete, navigate]);

  useEffect(() => {
    if (profile) {
      if (profile.nome) setNome(profile.nome);
      if (profile.data_nascimento) setDataNascimento(profile.data_nascimento);
      if (profile.bio) setBio(profile.bio);
      if (profile.gender) setGender(profile.gender);
    }
  }, [profile]);

  const validateAge = (birthDate: string): boolean => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    if (age < 18) {
      setAgeError('Você precisa ter pelo menos 18 anos para usar o Katuu');
      return false;
    }
    setAgeError('');
    return true;
  };

  const toggleInterest = (interestId: string) => {
    setSelectedInterests(prev =>
      prev.includes(interestId)
        ? prev.filter(i => i !== interestId)
        : [...prev, interestId]
    );
  };

  const handleNextStep = async () => {
    if (step === 1) {
      if (!nome.trim()) {
        toast({ variant: 'destructive', title: 'Por favor, insira seu nome' });
        return;
      }
      if (!dataNascimento) {
        toast({ variant: 'destructive', title: 'Por favor, insira sua data de nascimento' });
        return;
      }
      if (!validateAge(dataNascimento)) return;
      if (!gender) {
        toast({ variant: 'destructive', title: 'Por favor, selecione seu gênero' });
        return;
      }
      setStep(2);
    }
  };

  const handleComplete = async () => {
    if (selectedInterests.length < 3) {
      toast({ variant: 'destructive', title: 'Selecione pelo menos 3 interesses para continuar' });
      return;
    }
    setSaving(true);
    try {
      const { error: profileError } = await updateProfile({
        nome: nome.trim(),
        data_nascimento: dataNascimento,
        bio: bio.trim() || null,
        gender: gender as Gender,
      });

      if (profileError) {
        const msg = profileError.message || String(profileError);
        if (msg.includes('MINIMUM_AGE')) {
          setAgeError('Você precisa ter pelo menos 18 anos');
          setStep(1);
          setSaving(false);
          return;
        }
        throw profileError;
      }

      const { error: interestsError } = await updateInterests(selectedInterests);
      if (interestsError) throw interestsError;

      toast({ title: 'Perfil criado com sucesso!' });
      await executePendingOrNavigate('/location');
    } catch (error) {
      console.error('Error completing onboarding:', error);
      toast({ variant: 'destructive', title: 'Erro ao salvar perfil' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary p-6 flex items-center justify-center">
        <img src={logoKatu} alt="Katuu" className="w-20 h-auto" />
      </div>

      {/* Progress indicator */}
      <div className="flex justify-center gap-2 py-4">
        {[1, 2].map((s) => (
          <div
            key={s}
            className={`h-2 w-12 rounded-full transition-colors ${s <= step ? 'bg-accent' : 'bg-muted'
              }`}
          />
        ))}
      </div>

      <div className="p-4 page-enter">
        {/* Step 1: Basic Info */}
        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Complete seu perfil para começar</CardTitle>
              <CardDescription>
                Esses dados são necessários para que você possa interagir com outras pessoas nos locais.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome <span className="text-destructive">*</span></Label>
                <Input
                  id="nome"
                  placeholder="Como você quer ser chamado?"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  maxLength={50}
                />
              </div>

              <div className="space-y-2">
                <Label>Data de nascimento <span className="text-destructive">*</span></Label>
                <DateOfBirthPicker
                  value={dataNascimento}
                  onChange={(v) => {
                    setDataNascimento(v);
                    if (!v.includes('00')) validateAge(v);
                  }}
                />
                {ageError && (
                  <p className="text-sm text-destructive">{ageError}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Gênero <span className="text-destructive">*</span></Label>
                <Select value={gender} onValueChange={(v) => setGender(v as Gender)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione seu gênero" />
                  </SelectTrigger>
                  <SelectContent>
                    {GENDER_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio (opcional)</Label>
                <Textarea
                  id="bio"
                  placeholder="Uma breve descrição sobre você..."
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  maxLength={80}
                  rows={3}
                />
                <p className="text-xs text-muted-foreground text-right">
                  {bio.length}/80
                </p>
              </div>

              <Button
                onClick={handleNextStep}
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
                disabled={!!ageError}
              >
                Continuar
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Interests */}
        {step === 2 && (
          <InterestsStep
            selectedInterests={selectedInterests}
            onToggleInterest={toggleInterest}
            onNext={handleComplete}
            onBack={() => setStep(1)}
            categoryIndex={categoryIndex}
            setCategoryIndex={setCategoryIndex}
          />
        )}
      </div>
    </div>
  );
}
